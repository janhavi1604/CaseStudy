package comm;

public class User {
	
	void Regsitration(int userid,String username)
	{
		System.out.println("The user"+" "+userid+" "+username+" "+ "has sucessfully registerd");
	}

}
