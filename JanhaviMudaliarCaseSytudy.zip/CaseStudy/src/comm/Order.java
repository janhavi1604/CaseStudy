package comm;

public class Order {

	void placeorder(String book_name,int price)
	{
		System.out.println("Order placed of:"+" "+book_name+" "+"Price is:"+price);
	}
}
