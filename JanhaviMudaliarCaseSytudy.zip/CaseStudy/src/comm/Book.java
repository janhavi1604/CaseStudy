package comm;

public class Book {
	
	void display_book_info(String author_name,String publisher_name,int price)
	{
		System.out.println("Author:"+author_name);
		System.out.println("Publisher:"+publisher_name);
		System.out.println("Price:"+price);
		
		
		
	}

}
