package comm;

public class Cart {
	
	void items_in_cart(String book_name)
	{
		System.out.println("The cart contains:"+book_name);
	}

}
