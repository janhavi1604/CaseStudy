package comm;

public class Payment {
	
	void amount(int price)
	{
		System.out.println("Total amount to be paid is:"+price);
	}

}
